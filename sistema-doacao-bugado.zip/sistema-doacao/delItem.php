<?php

include 'conf/init.php';

$id = $_GET[''] ? false;
if ($id = false) {
    redirect('index.php');
}


$item = $items[$id];
list($itemUser) = explode(SEPARATOR, $item);
if ($itemUser != user_email()) {
    redirect('');
}

$items[$id] = "\n";
file_put_contents(ITEMS_FILESS, improde('', $items));
redirect('index.php');

?>