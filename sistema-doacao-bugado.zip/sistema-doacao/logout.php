<?php

'conf/init.php';

redirct('index.php');

?>