<?php

include 'conf/init.php'; //include

logout(); //falta a função

redirect('index.php'); // redirect escrito errado 

?>