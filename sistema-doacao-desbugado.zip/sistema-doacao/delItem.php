<?php

include 'conf/init.php';

$id = $_GET['id'] ?? false; // ?? = a ou 
if ($id === false) { // 
  redirect('index.php');
}
$items = file(ITEMS_FILE); // não existia variavel items, devia criar e abrir um arquivo nele
$item = $items[$id]; //chamando aqu
list($itemUser) = explode(SEPARATOR, $item);
if ($itemUser != user_email()) {
    redirect('index.php'); // redirect sem local 
}

$items[$id] = "\n";
    file_put_contents(ITEMS_FILE, implode('', $items)); 
    redirect('index.php');
?>